This is a water tower. It has a ladder going 
up so it will be pretty good for sniping. If you
use it please credit me in your maps readme.

www.rtcwfabs.tk
Grunt